// import { useState } from "react";
// import { 
//   View, 
//   Text, 
//   TextInput, 
//   TouchableOpacity, 
//   Alert, 
//   StyleSheet, 
//   ActivityIndicator 
// } from "react-native";
// import { useRouter } from "expo-router";
// import axios from "axios";

// export default function Login(): JSX.Element {
//   const router = useRouter();
//   const [email, setEmail] = useState<string>("");
//   const [password, setPassword] = useState<string>("");
//   const [loading, setLoading] = useState<boolean>(false);
//   const [googleLoading, setGoogleLoading] = useState<boolean>(false);

//   const handleLogin = async () => {
//     if (!email.trim() || !password.trim()) {
//       Alert.alert("Error", "Email and password cannot be empty.");
//       return;
//     }

//     setLoading(true);
//     try {
//       const response = await axios.post("https://dev.safeaven.com/api/login", { email, password });
//       if (response.status === 200) {
//         Alert.alert("Success", "Login Successful!");
//         router.push("/(app)/Dashboard");
//       } else {
//         throw new Error("Unexpected response from server.");
//       }
//     } catch (error: any) {
//       console.error("Login error:", error);
//       const errorMessage =
//         error.response?.data?.message || "An unexpected error occurred. Please try again.";
//       Alert.alert("Login Failed", errorMessage);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleGoogleLogin = async () => {
//     setGoogleLoading(true);
//     try {
//       // Simulate Google login process (Replace with actual Google Auth integration)
//       setTimeout(() => {
//         setGoogleLoading(false);
//         Alert.alert("Success", "Logged in with Google!");
//         router.push("/(app)/Dashboard");
//       }, 1500);
//     } catch (error) {
//       console.error("Google Login error:", error);
//       Alert.alert("Login Failed", "Failed to login with Google.");
//     } finally {
//       setGoogleLoading(false);
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Login</Text>

//       <TextInput
//         style={styles.input}
//         placeholder="Enter Email"
//         placeholderTextColor="#A1A1A1"
//         value={email}
//         onChangeText={setEmail}
//         keyboardType="email-address"
//         autoCapitalize="none"
//       />

//       <TextInput
//         style={styles.input}
//         placeholder="Enter Password"
//         placeholderTextColor="#A1A1A1"
//         value={password}
//         onChangeText={setPassword}
//         secureTextEntry
//       />

//       <TouchableOpacity 
//         style={[styles.button, loading && styles.buttonDisabled]} 
//         onPress={handleLogin} 
//         disabled={loading}
//       >
//         {loading ? <ActivityIndicator color="white" /> : <Text style={styles.buttonText}>Login</Text>}
//       </TouchableOpacity>

//       <TouchableOpacity onPress={() => router.push('/register')} style={styles.registerContainer}>
//         <Text style={styles.registerText}>Don't have an account? Register</Text>
//       </TouchableOpacity>

//       {/* OR Separator */}
//       <View style={styles.separatorContainer}>
//         <View style={styles.separator} />
//         <Text style={styles.separatorText}>OR</Text>
//         <View style={styles.separator} />
//       </View>

//       {/* Google Login Button */}
//       <TouchableOpacity 
//         style={[styles.googleButton, googleLoading && styles.buttonDisabled]} 
//         onPress={handleGoogleLogin} 
//         disabled={googleLoading}
//       >
//         {googleLoading ? (
//           <ActivityIndicator color="white" />
//         ) : (
//           <Text style={styles.googleButtonText}>Login with Google</Text>
//         )}
//       </TouchableOpacity>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     padding: 20,
//     backgroundColor: "#f8f9fa",
//   },
//   title: {
//     fontSize: 26,
//     fontWeight: "bold",
//     color: "#333",
//     marginBottom: 20,
//   },
//   input: {
//     width: "100%",
//     height: 50,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 10,
//     paddingHorizontal: 15,
//     backgroundColor: "#fff",
//     color: "#333",
//     marginBottom: 10,
//     fontSize: 16,
//   },
//   button: {
//     width: "100%",
//     backgroundColor: "#007bff",
//     paddingVertical: 14,
//     borderRadius: 10,
//     alignItems: "center",
//     justifyContent: "center",
//     marginVertical: 10,
//   },
//   buttonDisabled: {
//     opacity: 0.7,
//   },
//   buttonText: {
//     color: "white",
//     fontSize: 18,
//     fontWeight: "600",
//   },
//   registerContainer: {
//     marginTop: 15,
//   },
//   registerText: {
//     color: "#007bff",
//     fontSize: 16,
//   },
//   separatorContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginVertical: 20,
//     width: "100%",
//   },
//   separator: {
//     flex: 1,
//     height: 1,
//     backgroundColor: "#ccc",
//   },
//   separatorText: {
//     marginHorizontal: 10,
//     fontSize: 14,
//     color: "#555",
//   },
//   googleButton: {
//     width: "100%",
//     backgroundColor: "#db4437",
//     paddingVertical: 14,
//     borderRadius: 10,
//     alignItems: "center",
//     justifyContent: "center",
//     marginBottom: 10,
//   },
//   googleButtonText: {
//     color: "white",
//     fontSize: 18,
//     fontWeight: "600",
//   },
// });


import { useState } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  Alert, 
  StyleSheet, 
  ActivityIndicator 
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import axios from "axios";
import { checkUserProgress } from "./utils/checkUserProgress";

export default function Login(): JSX.Element {
  const router = useRouter();
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [googleLoading, setGoogleLoading] = useState<boolean>(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert("Error", "Email and password cannot be empty.");
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post("https://dev.safeaven.com/api/login", { email, password });

      if (response.status === 200 && response.data.jwt) {
        const token = response.data.jwt;
        await AsyncStorage.setItem("jwt_token", token); // Store JWT token
        Alert.alert("Success", "Login Successful!");
        await checkUserProgress(token)
      } else {
        throw new Error("Invalid response from server.");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      const errorMessage =
        error.response?.data?.message || "An unexpected error occurred. Please try again.";
      Alert.alert("Login Failed", errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      // Simulate Google login process (Replace with actual Google Auth integration)
      setTimeout(async () => {
        const fakeToken = "google-auth-token-123"; // Mock token
        await AsyncStorage.setItem("jwt_token", fakeToken); // Store JWT token
        setGoogleLoading(false);
        Alert.alert("Success", "Logged in with Google!");
        router.push("/(app)/Dashboard");
      }, 1500);
    } catch (error) {
      console.error("Google Login error:", error);
      Alert.alert("Login Failed", "Failed to login with Google.");
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        placeholderTextColor="#A1A1A1"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <TextInput
        style={styles.input}
        placeholder="Enter Password"
        placeholderTextColor="#A1A1A1"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <TouchableOpacity 
        style={[styles.button, loading && styles.buttonDisabled]} 
        onPress={handleLogin} 
        disabled={loading}
      >
        {loading ? <ActivityIndicator color="white" /> : <Text style={styles.buttonText}>Login</Text>}
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.push('/register')} style={styles.registerContainer}>
        <Text style={styles.registerText}>Don't have an account? Register</Text>
      </TouchableOpacity>

      {/* OR Separator */}
      <View style={styles.separatorContainer}>
        <View style={styles.separator} />
        <Text style={styles.separatorText}>OR</Text>
        <View style={styles.separator} />
      </View>

      {/* Google Login Button */}
      <TouchableOpacity 
        style={[styles.googleButton, googleLoading && styles.buttonDisabled]} 
        onPress={handleGoogleLogin} 
        disabled={googleLoading}
      >
        {googleLoading ? (
          <ActivityIndicator color="white" />
        ) : (
          <Text style={styles.googleButtonText}>Login with Google</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f8f9fa",
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    height: 50,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 15,
    backgroundColor: "#fff",
    color: "#333",
    marginBottom: 10,
    fontSize: 16,
  },
  button: {
    width: "100%",
    backgroundColor: "#007bff",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginVertical: 10,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
  registerContainer: {
    marginTop: 15,
  },
  registerText: {
    color: "#007bff",
    fontSize: 16,
  },
  separatorContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 20,
    width: "100%",
  },
  separator: {
    flex: 1,
    height: 1,
    backgroundColor: "#ccc",
  },
  separatorText: {
    marginHorizontal: 10,
    fontSize: 14,
    color: "#555",
  },
  googleButton: {
    width: "100%",
    backgroundColor: "#db4437",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
  },
  googleButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
});

