// import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";
// import { useRouter } from "expo-router";

// export default function MainPage() {
//   const router = useRouter();

//   return (
//     <View style={styles.container}>
//       {/* Logo */}
//       <Image 
//         source={require("../../assets/images/favicon.png")} // Replace with your logo
//         style={styles.logo} 
//         resizeMode="contain"
//       />

//       <Text style={styles.title}>Welcome to SafeHaven</Text>
//       <Text style={styles.subtitle}>Secure your journey with us</Text>

//       {/* Buttons Container (at the bottom) */}
//       <View style={styles.buttonContainer}>
//         {/* Sign In Button */}
//         <TouchableOpacity 
//           style={styles.button} 
//           onPress={() => router.push("/(auth)/login")}
//         >
//           <Text style={styles.buttonText}>Sign In</Text>
//         </TouchableOpacity>

//         {/* Sign Up Button */}
//         <TouchableOpacity 
//           style={[styles.button, styles.signupButton]} 
//           onPress={() => router.push("/(auth)/register")}
//         >
//           <Text style={[styles.buttonText, styles.signupButtonText]}>Sign Up</Text>
//         </TouchableOpacity>
//       </View>
//     </View>
//   );
// }

// // Styles
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#ffffff", // White background
//     paddingHorizontal: 20,
//   },
//   logo: {
//     width: 140,
//     height: 140,
//     marginBottom: 20,
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: "bold",
//     color: "#333333", // Dark gray for contrast
//     marginBottom: 5,
//   },
//   subtitle: {
//     fontSize: 16,
//     color: "#666666", // Lighter gray for a subtle touch
//     marginBottom: 40,
//   },
//   buttonContainer: {
//     position: "absolute",
//     bottom: 50, // Positioned at the bottom
//     width: "90%",
//   },
//   button: {
//     width: "100%",
//     backgroundColor: "#FF7300", // Orange theme
//     paddingVertical: 16,
//     borderRadius: 12,
//     alignItems: "center",
//     justifyContent: "center",
//     marginVertical: 10,
//     shadowColor: "silver",
//     shadowOpacity: 0.2,
//     shadowOffset: { width: 0, height: 3 },
//     elevation: 5,
//   },
//   signupButton: {
//     backgroundColor: "#ffffff", // White button for contrast
//     borderWidth: 2,
//     borderColor: "silver",
//   },
//   buttonText: {
//     color: "#ffffff",
//     fontSize: 18,
//     fontWeight: "bold",
//   },
//   signupButtonText: {
//     color: "#FF7300", // Orange text for Sign Up button
//   },
// });

import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";
import { useRouter } from "expo-router";

export default function MainPage() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {/* Logo */}
      <Image 
        source={require("../../assets/images/favicon.png")} // Replace with your logo
        style={styles.logo} 
        resizeMode="contain"
      />

      <Text style={styles.title}>Welcome to SafeHaven</Text>
      <Text style={styles.subtitle}>Secure your journey with us</Text>

      {/* Buttons Container */}
      <View style={styles.buttonContainer}>
        {/* Sign In Button */}
        <TouchableOpacity 
          style={styles.button} 
          onPress={() => router.push("/(auth)/login")}
        >
          <Text style={styles.buttonText}>Sign In</Text>
        </TouchableOpacity>

        {/* Sign Up Button */}
        <TouchableOpacity 
          style={[styles.button, styles.signupButton]} 
          onPress={() => router.push("/(auth)/register")}
        >
          <Text style={[styles.buttonText, styles.signupButtonText]}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFF8E1", // Soft orange background
    paddingHorizontal: 20,
  },
  logo: {
    width: 140,
    height: 140,
    marginBottom: 20,
    marginTop: -50, // Move the logo higher
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#FF6F00", // Deep orange
    marginBottom: 5,
    textTransform: "uppercase",
    letterSpacing: 1.2,
  },
  subtitle: {
    fontSize: 16,
    color: "#8D6E63", // Warm brownish shade for contrast
    marginBottom: 60,
    fontStyle: "italic",
  },
  buttonContainer: {
    position: "absolute",
    bottom: 50, // Buttons at the bottom
    width: "90%",
  },
  button: {
    width: "100%",
    backgroundColor: "#FF9800", // Vibrant orange
    paddingVertical: 16,
    borderRadius: 30, // More rounded buttons
    alignItems: "center",
    justifyContent: "center",
    marginVertical: 10,
    shadowColor: "#FF6F00",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  signupButton: {
    backgroundColor: "#FFF8E1", // Matching background
    borderWidth: 2,
    borderColor: "#FF9800",
  },
  buttonText: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "bold",
  },
  signupButtonText: {
    color: "#FF9800", // Orange text for Sign Up button
  },
});